<?php
/**
* @version		1.5.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.php
**/

defined('_OFFSITE_') or die('Access Denied');

require ('offline-theme/index.php');

