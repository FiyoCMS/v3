<?php
/**
* @version		2.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2012 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.php
**/


if(!defined('_FINDEX_'))
{
	ob_start();
	session_start();

	//set mulai session
	//mendefinisikan _FINDEX_ sebagai halaman utama
	define('_FINDEX_', 'BACK' );

	$start_time = microtime(TRUE);
	define('_START_TIME_', $start_time );


	//mengecek file konfigurasi
	if(!file_exists('../config.php')) 
		header("location:../");
		
	$sn = substr($_SERVER['PHP_SELF'],1);
	$sm = strpos($sn,'/');
	$sm = substr($sn,0,$sm);
	define('_ADMINPANEL_', $sm );

	require_once ('system/core.php');
} else {
		
	define('_ADMINPANEL_', basename(__dir__));

	//memuat file pendukung query dan fungsi lainya
	require_once ('system/rcore.php');

}


//melakukan pengecekan login AdminPanel
check_backend_login();

$output = ob_get_contents();
ob_end_clean();

if(Input::server('https') == 'on') $output = str_replace("http://", "https://", $output);
echo $output;
ob_end_flush();


/* efile pake USER NEW 


199407262016092001		1994-07-26
199405242016092003		1994-05-24
199312292015021001		1993-12-29

Login Tambah Telp. / Email


Masuk atau dari kemen tanpa masuk data


dokumen terupload disesuaikan NIP dan kode




ROLE ADMIN PENAWRAWAN DI TAWARKAN KE KABID

Masukan data ke lolos butuh sm penawaran, kanreg


*/