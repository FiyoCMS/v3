<?php
/**
* @version		2.0.2
* @package		Fiyo CMS
* @copyright	Copyright (C) 2015 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
**/

defined('_FINDEX_') or die('Access Denied');

?>
<div id="app_header">
	<div class="warp_app_header">		
		<div class="app_title">Dashboard</div>
		
	</div>
</div>
<div style="padding-bottom: 10px; width: 100%;">
<div class="col-lg-12 full">	
	<div class="box graph">											
		<div id="page-configuration" class="in">
		</div>
	</div>
	
	<div class="box statistic">	
		<div class="mini-box box-2 today-visitor"><h3>5</h3><span>Data TBIB Baru</span><i class="icon icon-calendar-empty"></i>
		</div>
		<div class="mini-box box-2 today-visitor"><h3>3</h3><span>TBIB Sudah Proses</span><i class="icon icon-calendar-empty"></i>
		</div>
		<div class="mini-box box-3 monthly-visitor"><h3>0</h3><span>Data Siap Tes</span><i class="icon icon-calendar"></i>
		</div>
		<div class="mini-box box-4 total-visitor"><h3>0</h3><span>Peserta Lolos TBIB</span><i class="icon icon-signal"></i>
		</div>
	</div>	
</div>
<div class="clearfix"></div>
