<?php 
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2016 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
**/

session_start();
define('_FINDEX_','BACK');

require_once ('../../../system/jscore.php');

if(checkMobile()) {
	$d13 = 6;
} else {
	$d13 = 13;
}

$uniqueVisitor = $allVisitor = $newVisitor = $dateList = '';

$x = $d13;
$dtf = date('Y-m-d 00:00:00',strtotime("-$x days"));
$z = $x-1;
$dts = date('Y-m-d 00:00:00',strtotime("+1 days"));	
$st = FDBPrefix."statistic";

$row = DB::Table("$st")->select("time,user_id,ip,DATE_FORMAT(time,'%Y-%m-%d') as waktu")->where("time BETWEEN '$dtf' AND '$dts'")->get();


foreach ($row as $data) {
  $id = $data['waktu'];
  if (isset($result[$id])) {
     $result[$id][] = $data;
  } else {
     $result[$id] = array($data);
  }
  
  $result[$id]['hits'] = count($result[$id]);
  $result[$id]['unique'] = count($result['ip'][0], COUNT_RECURSIVE)+1;
}



for($x = $d13; $x >= 0; $x--) {
	$dtf = date('Y-m-d',strtotime("-$x days"));
	
	if(!isset($result[$dtf])) 
	{
		$allVisitor .= 0;  
		$uniqueVisitor .= 0;
	} else {
		
		$allVisitor .= $result[$dtf]['hits'];
		$uniqueVisitor .= $result[$dtf]['unique'];
	}
	
	
	if($x != 0) $allVisitor .= ",";
	if($x != 0) $uniqueVisitor .= ",";
}


$date = date("d-m-Y",strtotime("-$d13 days"));

$D = substr($date,0,2);
$M = substr($date,3,2)-1;
$Y = substr($date,6,4);

?>

<script>
$(function () {		
    var chart;
	var allVisitor = [<?php echo $allVisitor;?>];
	var uniqueVisitor = [<?php echo $newVisitor;?>];
	var reVisitor = [<?php echo $uniqueVisitor;?>];
    $(document).ready(function() {
		function chartStat() {
        chart = new Highcharts.Chart({
			colors: [ '#15aa00', '#f85d11'],
            chart: {
                renderTo: 'statistic',
                 type: 'area',
            },
            title: {
                text: ''
            },
            xAxis: {
                type: 'datetime',
                labels: {
                overflow: 'justify'
                }
            },
            yAxis: {
                title: {
                    text: null
                },
            },
            tooltip: {
                valueSuffix: null,
                shared: true,
            },
            plotOptions: {
                area: {
                    lineWidth: 3,
                    states: {
                        hover: {
                            lineWidth: 3,
                        }
                    },
                    marker: {       
						fillColor: '#FFFFFF',
						lineWidth: 2,						
						radius: 4,
						symbol : 'circle',
						lineColor: null // inherit from series
                    },
                    pointInterval: 3600000*24, // one hour
                    pointStart: Date.UTC( <?php echo $Y;?>,  <?php echo $M;?>, <?php echo $D;?>, 0, 0, 0)
                }
				,series: {
					fillOpacity: 0.05,						
				},
            },
            credits: {
                enabled: false
            },
            series: [{
                name: 'Hits',
                data: allVisitor
    
            },{
                name: 'Visitor',
                data: reVisitor
            }
			]
            ,
            navigation: {
                menuItemStyle: {
                    fontSize: '10px'
                }
            }
        });
		}
		
		chartStat();
		
		function chartResize(width, height){		
			var w = $(window).width();
			w = parseInt(w);
			var r = $('rect').width();
			r = parseInt(r);
			if(w >= 980) var c = 220; 
			else if(w > 780) var c = 110; 
			else if(w <= 780) var c = 0; 
			var a = $(".statistic").width();
			var b = $("#statistic").height();
			a = parseInt(a);
			b = parseInt(b);
			chart.setSize(a-c-5,b);
			if($('.hide-sidebar').length && a > 200) {		
				chart.setSize(a+c-5,b);			
			}
			else if(width > 980)
			{
				chart.setSize(a-c-5,b);
			}
			else			
				chart.setSize(a-c-5,b);
		}
		$('.changeSidebarPos').on('click', function(e) {
			chartResize(null, null);
		});
			
		var prevHeight = $(window).height();
		var prevWidth = $(window).width();
		
		$(".statistic").resize(function() {
			chartResize(prevWidth, prevHeight);
		});

    }); 
    
});
</script>