<?php
$app_name='Fi Contact';
$app_version='1.0 Beta';
$app_date='25 September 2011';
$app_author='First Ryan';
$app_author_url='http://portofolio.web.id';
$app_author_email='firstryan@gmail.com';
$app_desc='Anda dapat menampilkan kontak personal atau grup.';
?>
