<?php
/**
* @version		2.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2014 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

defined('_FINDEX_') or die('Access Denied');

?>

<div class="box-left full">
	<div class="box">								
		<header class="dark">
			<h5></h5>
		</header>								
		<div>
			<table>
				<tr>
					<td>Refensi Proyek</td>
					<td><?php
						$proyek = Database::table('proyek')
								->select('id,nama')
								->get();
								
						$row = [];
						foreach($proyek as $k=>$v) {
							$row[$v['id']] = $v['nama'];
						}
						
						echo Form::select(
							'proyek',$row, 
							["class" => "form-control", "required"]
						);
					?>
					</td>
				</tr>
				
				<tr>
					<td>Minggu Ke-</td>
					<td>
					<?php
						echo Form::text(
							'mingguke', 
							'', 
							["class" => "form-control numeric", "required"]
						);
					?>
					</td>
				</tr>
				
				<tr>
					<td>Rencana Minggu ini</td>
					<td>
					<?php
						echo Form::text(
							'rencana', 
							'', 
							["class" => "form-control", "required"]
						);
					?>
					</td>
				</tr>
				
				<tr>
					<td>Rencana Kumulatif s/d Minggu ini</td>
					<td>
					<?php
						echo Form::text(
							'rencana_kumulatif', 
							'', 
							["class" => "form-control", "required"]
						);
					?>
					</td>
				</tr>
				
				<tr>
					<td>Realisasi Minggu ini</td>
					<td>
					<?php
						echo Form::text(
							'realisasi', 
							'', 
							["class" => "form-control", "required"]
						);
					?>
					</td>
				</tr>
				
				<tr>
					<td>Realisasi Kumulatif s/d Minggu ini</td>
					<td>
					<?php
						echo Form::text(
							'realisasi_kumulatif', 
							'', 
							["class" => "form-control", "required"]
						);
					?>
					</td>
				</tr>
				
				
				<tr>
					<td>Data Pendukung</td>
					<td>					
					<?php
						if(!empty($data['file'])) echo "<img style='max-width: 400px' src='../media/files/$data[file]'>";
					?>
					<?php
						echo Form::hidden('file');
					?><br><span class="form-file form-control">
					<?php
						echo Form::file(
							'newfile', 
							'', 
							["class" => "form-control", "required", "rows" => "4"]
						);
					?>
					</span>
					</td>
				</tr>
			</table>			
		</div>  
	</div>
</div>
 
