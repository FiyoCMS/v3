<?php
/**
* @version		2.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2014 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/
defined('_FINDEX_') or die('Access Denied');

$app = [
	'name'		=> 'Kemajuan Pekerjaan',
	'table'		=> $_REQUEST['app'],
	'folder'	=> 'app_'.$_REQUEST['app'],
];

$view = Input::get('view');
$act = Input::get('act');

switch($view)
{	
	default :
	 switch($act) {	
		default :
		 require('view/view_user.php');
		break;
		case 'add':	 
		 require('view/add_user.php');
		break;
		case 'edit':
		 require('view/edit_user.php');
		break;
		case 'view':
		 require('view/view_user.php');
		break;			
	}
	break;
	case 'group': 		 
	 switch($act) {	
		default :	 
		 require('view/group/view_group.php');
		break;
		case 'edit':	 
		 require('view/group/edit_group.php');
		break;
		case 'add':	 
		 require('view/group/add_group.php');
		break;	
	}	
	break;	
}