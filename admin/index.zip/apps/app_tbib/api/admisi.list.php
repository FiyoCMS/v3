<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2018 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

session_start();
header('Content-Type: application/json');
if(!$_SESSION['USER_LEVEL'] AND !isset($_GET['iSortCol_0'])) die ('Access Denied!');
define('_FINDEX_','BACK');
require('../../../system/jscore.php');

	/* Array of database columns which should be read and sent back to DataTables. Use a space where
	 * you want to insert a non-database field (for example a counter or static image)
	 */
	$sTable = FDBPrefix."mutasi_category";
	$kategori = 1;
	$cat = 'antarkab';

	$aColumns =[
		"$sTable.id", 
		'nama', 
		"keterangan", 
		"s1", 
		's2', 
		"s3",  
		"s4", 
		's5', 
		"s6",  
		"s7", 
		's8', 
		"s9",  
		"s10", 
		];
		
	$aWhereColumns =[
		"$sTable.id", 
		'nama', 
		"keterangan", 
		"s1", 
		's2', 
		"s3",  
		"s4", 
		's5', 
		"s6",  
		"s7", 
		's8', 
		"s9",  
		"s10", 
	];
	
	
	/* Indexed column (used for fast and accurate table cardinality) */
	$sIndexColumn = "id";
	
	
	/* 
	 * Paging
	 */
	$sLimit = "LIMIT 10";
	if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
	{
		$sLimit = "LIMIT ".intval( $_GET['iDisplayStart'] ).", ".
			intval( $_GET['iDisplayLength'] );
	}
	
	
	/*
	 * Ordering
	 */
	$sOrder = "ORDER BY id  ASC";
	
	if (isset($_GET['iSortCol_0']) AND !empty($_GET['iSortCol_0']))
	{
		$sOrder = "ORDER BY  ";
		for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
		{
			if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
			{
				$data = str_replace(".","`.`",$aColumns[ intval( $_GET['iSortCol_'.$i] ) ]);				
				$c =strpos($aColumns[ intval( $_GET['iSortCol_'.$i] ) ],"as");
				if($c) { $c += 3;
					$data = substr($aColumns[ intval( $_GET['iSortCol_'.$i] ) ], $c);
				}
				$sOrder .= "`". $data ."` ".
					($_GET['sSortDir_'.$i]==='asc' ? 'asc' : 'desc') .", ";
			}
		}
		
		$sOrder = substr_replace( $sOrder, "", -2 );
		if ( $sOrder == "ORDER BY" )
		{
			$sOrder = "";
		}
	}
	
	/* 
	 * Filtering
	 * NOTE this does not match the built-in DataTables filtering which does it
	 * word by word on any field. It's possible to do here, but concerned about efficiency
	 * on very large tables, and MySQL's regex functionality is very limited
	 */
		
	$sWhere = " ";
	if ( isset($_GET['sSearch']) && $_GET['sSearch'] != "" )
	{
		$sWhere .= " AND(";
		for ( $i=0 ; $i<count($aWhereColumns) ; $i++ )
		{

			$data = str_replace(".","`.`",$aWhereColumns[$i]);
			$sWhere .= "`".$data."` LIKE '%".addslashes( $_GET['sSearch'] )."%' OR ";
		}
		$sWhere = substr_replace( $sWhere, "", -3 );
		$sWhere .= ')';
	}
	
	/* Individual column filtering */
	for ( $i=0 ; $i<count($aColumns) ; $i++ )
	{
		if ( isset($_GET['bSearchable_'.$i]) && $_GET['bSearchable_'.$i] == "true" && $_GET['sSearch_'.$i] != '' )
		{
			if ( $sWhere == "AND " )
			{
				$sWhere .= " ";
			}
			else
			{
				$sWhere .= " AND ";
			}
			$sWhere .= "`".$aColumns[$i]."` LIKE '%".addslashes($_GET['sSearch_'.$i])."%' ";
		}
	}	
	
	/*
	 * SQL queries
	 * Get data to display
	 */
	$sQuery = "
		SELECT SQL_CALC_FOUND_ROWS `".str_replace(" as ", "` as `", str_replace(".","`.`", str_replace(" , ", " ", implode("`, `", $aColumns))))."`
		FROM  $sTable 
		$sWhere 
		$sOrder
		$sLimit
		";

		
	$rResult = Database::query($sQuery);	
	//echo DB::$query;
	/* Data set length after filtering */
	$sQuery = "
		SELECT FOUND_ROWS()
	";
	$rResultFilterTotal = Database::query($sQuery)->fetchColumn();
	$iFilteredTotal = $rResultFilterTotal;
	//echo $iFilteredTotal;
	/* Total data set length */
	$sQuery = "
		SELECT COUNT(`".$sIndexColumn."`)
		FROM   $sTable
	";	
	$rResultTotal = Database::query($sQuery)->fetchColumn();
	$iTotal = $rResultTotal;	
	/*
	 * Output
	 */

	$output = array(
		"sEcho" => intval(@$_GET['sEcho']),
		"iTotalRecords" => $iTotal,
		"iTotalDisplayRecords" => $iFilteredTotal,
		"aaData" => array()
	);
	
	foreach ( $rResult as $aRow )
	{
		$row = array();
		for ( $i=0 ; $i<count($aColumns) ; $i++ )
		{							
			$checkbox ="<label><input type='checkbox' data-name='rad-$aRow[id]' name='check[]' value='$aRow[id]' rel='ck' ><span class='input-check'></span></label>";
			$title = $aRow['nama'];
				
							
			if ( $i == 0 )
			{			
				$row[] = $checkbox; 
			}				
			else if ( $i == 1 )
			{	
				$row[] ="<a class='tips select' rel='$aRow[id]' title='".Edit."' href='?app=mutasi&view=admisi&act=edit&id=$aRow[id]' target='_self' redata-placement='right'>$title</a>";	
				
			}			
			else if ( $i == 2 )
			{			
				if($aRow['s1']) {
					$step = "";
					for($i = 1; $i < 11; $i++)
						if($aRow['s'.$i]) {
							$group = DB::table(FDBPrefix.'user_group')->select('group_name')->where("id=". $aRow['s'.$i])->get()[0]['group_name'];
							if($i != 1) 
							$step .= " &nbsp; <i class='icon-long-arrow-right'></i> &nbsp; " ;
							$step .= $group ;
						}
				}
				else {
					$step = "";
				}
				$row[] = "<div>$step</div>";
			}	
		}
		$output['aaData'][] = $row;
	}
	
	echo json_encode( $output );
?>