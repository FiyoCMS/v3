<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2018 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

session_start();
define('_FINDEX_','BACK');
header('Content-Type: application/json');
if(!isset($_SESSION['USER_LEVEL']) AND $_SESSION['USER_LEVEL'] > 2 AND Input::post('pos') AND Input::post('id')) die ();
require_once ('../../../system/jscore.php');


if(Input::post('pos')) {
	$s = Input::post('pos');
	$pos = "s".Input::post('pos');
	$posu = $pos."_id";
	DB::table(FDBPrefix.'mutasi_data')->where('id='.Input::post('id'))->update([$pos => date("Y-m-d"), 'tgl_update' => date("Y-m-d"), $posu => USER_ID, 'status' => $s]);
	echo 1;
} else {
	echo 0;
}
