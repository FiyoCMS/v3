<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2017 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

defined('_FINDEX_') or die('Access Denied');



$app 	= $_REQUEST['app']; 
$table 	= FDBPrefix.$_REQUEST['app']; 

$view = Input::get('view');
$act = Input::get('act');

require_once('model/restrict.php');
require_once('model/query.php');
require_once('model/funct.php');


//Add new data
if(Input::post('save_admisi')) {
	$data 	= Input::$post;
	if(Query::saveAdmisi($data)) 
		redirect('?app='.$app.'&view=admisi&act=edit&id='.DB::$last_id);	
}

if(Input::post('edit_admisi')) {	
	$data 	= Input::$post;
	$id 	= Input::get('id');
	if(Query::editAdmisi($data, $id)) refresh();	
}




if($view == 'antarkab' AND Input::get('act') == 'edit') {
	$data = Restrict::antarkab();
	if($data === false) {
		redirect("?app=mutasi&view=antarkab");
	}
	else {
		if(Input::post('edit_antarkab')) {	
			$data 	= Input::$post;
			$id 	= Input::get('id');
			if(Query::editMutasi($data, $id, 1)) 
				refresh();
		}
	}
}



//Delete Data
if(Input::post('delete_confirm')) {	
	
	$source = Input::post('check');
	$source = multipleSelect($source);
	$delete = multipleDeletes(FDBPrefix.'mutasi_data', $source);

	if($delete  == 'deleted') {		
		notice('info',Status_Deleted);
		refresh();	
	}
	else if($delete  == 'cantdelete') {		
		notice('error',Status_Cant_Delete);
		refresh();	
	}
	else if($delete  == 'noempty'){
		notice('error',Status_Not_Empty);
		refresh();	
	}
	else
		notice('error',Please_Select_Item);
	
}



// Redirect when User-Id not found
if(Input::get('act') == 'edit' AND !Input::post('edit')) {
	if(Input::get('act'))
	if($_REQUEST['act'] == 'edit' AND !Req::get('view')){
		$id = (int)Input::get('id');
		$row = Database::table($table)->where("id=$id")->get(); 
		$jml=count($row);
		if($jml <= 0) {
			notice('info','Sorry, data refference not found');
			redirect("?app=$app");
		}
	}
}
