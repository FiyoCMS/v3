
<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2017 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

class Query {
	public static $message = null;
	protected static $status = false;
	
	public function saveAdmisi($data) {		
		$data = array_query($data,[
			'nama', 's1', 's2', 's3', 's4', 's5', 's6', 's7', 's8', 's9', 's10']);
			
		//validation
		$valid = Validator::is_valid($data, [
			'nama' => 'required',
			's1' => 'required',
		]);
		
		//query		
		if($valid === true) {
			if(Database::table(FDBPrefix.'article')->insert($data)) {
				self::$message = Status_Saved;	
				notice('success', self::$message);	
				return true;
			}
			else {
				self::$message = Status_Fail;
				notice('error',Status_Fail);				
				return false;
			}
			
		}	
		else {		
			self::$message = $valid; 			
			notice('error', $valid);		
			return false;
		}
	}
	
	public function editAdmisi($data, $id) {
		$data = array_query($data,[
			'nama', 's1', 's2', 's3', 's4', 's5', 's6', 's7', 's8', 's9', 's10']);
			
		//validation
		$valid = Validator::is_valid($data, [
			'nama' => 'required',
			's1' => 'required',
		]);
		
		//query		
		if($valid === true) {
			if(Database::table(FDBPrefix.'mutasi_category')->where("id=$id")->update($data)){
				self::$message = Status_Saved;	
				notice('success', self::$message);	
				return true;
			}
			else {
				self::$message = Status_Fail;
				notice('error',Status_Fail);
				return false;
			}
			
		}	
		else {		
			self::$message = $valid; 			
			notice('error', $valid);		
			return false;
		}
	}
	
	
	public function delete($id) {
		if(Database::table('permasalahan')->delete("id = $id")) {
				self::$message = Status_Deleted;	
				notice('info', Status_Deleted);	
				return true;
		}
		else {
			notice('error',Status_Fail);				
			return false;
		}
	}

	
	
	public function editMutasi($data, $id, $cat) {
		$data = array_query($data,[
		'sp1',
		'no_sp1',
		'tgl_sp1',
		'tgl_sp1n',
		'sp2',
		'no_sp2',
		'tgl_sp2',
		'tgl_sp2n',
		'sp3',
		'no_sp3',
		'tgl_sp3',
		'tgl_sp3n',
		'kab_asal',
		'kab_tujuan',
		'nip',
		'nama',
		'ubah_lamp',
		'lamp_ka_skpd',
		'pns_bkd',
		'pns_keu',
		'pns_rs',
		'lamp_tambahan',
		'no_sk',
		'no_pengantar',
		'tgl_sk',
		'tgl_update' => date("Y-m-d"),
		'notadinas2',
		'notadinas3',
		'kategori' => $cat]);
			
		//validation
		$valid = Validator::is_valid($data, [
			'no_sp1' => 'required',
			'sp1' => 'required',
		]);
		
		//query		
		if($valid === true) {
			if(Database::table(FDBPrefix.'mutasi_data')->where("id=$id")->update($data)){
				self::$message = Status_Saved;	
				notice('success', self::$message);	
				return true;
			}
			else {
				self::$message = Status_Fail;
				notice('error',Status_Fail);
				return false;
			}
			
		}	
		else {		
			self::$message = $valid; 			
			notice('error', $valid);		
			return false;
		}
	}
	
	
}
