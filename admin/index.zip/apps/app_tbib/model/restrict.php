
<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2017 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

class Restrict {
	public static $message = null;
	protected static $status = false;
	
	public function antarkab() {
        $sTable = FDBPrefix."mutasi_data";
        $sTable2 = FDBPrefix."mutasi_category";

        $level = "";
        $userLevel = USER_LEVEL;
        if($userLevel > 2)
        for($i = 1; $i < 11; $i++) {
            $n = $i - 1;
            if($n > 0) {
                $sn = "AND s".$n."_id !=0";
            } else {
                $sn = "";
            }

            $sm = "AND s".$i."_id = 0";
        
            if($i == 10)
                $level .= "($sTable2.s".$i." = $userLevel $sn) AND ";
            else
                $level .= "($sTable2.s".$i." = $userLevel $sn) OR ";

        }
        

        $data = DB::table($sTable)->where(" $level $sTable.id = ". Input::get('id'))
        ->leftJoin($sTable2,"$sTable.kategori = $sTable2.id")->get()[0];

        if(USER_LEVEL > 2)
        for($i = 1; $i < 11; $i++) {
            $j = $i + 1;
            $v = $data["s".$i."_id"];
            $n = $data["s".$i];
            if($v AND $n == USER_LEVEL ) return false;
        }

        return $data;
	}
	
	
}
