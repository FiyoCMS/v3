<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2018 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
**/

defined('_FINDEX_') or die('Access Denied');

?>
	<div class="app_main box full">
		<header>
			<h5>Detail</h5>
		</header>
		<div>
			<table>
				<tr>
					<td>Kategori Mutasi</td>
					<td>					
					<?php		
						echo Form::text(
							'nama', '',
							["class" => "form-control", "required"]
						);
					
					?>					
					</td>
				</tr>
				<tr>
					<td>Admisi 1</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's1',$sel, '',
							["class" => "form-control filter", "required"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 2</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's2',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 3</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's3',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 4</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's4',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 5</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's5',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 6</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's6',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 7</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's7',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 8</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's8',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 9</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's9',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
				<tr>
					<td>Admisi 10</td>
					<td><?php
						$sql = Database::table(FDBPrefix.'user_group')
								->select('level, group_name')
								->where('level > 2')
								->get();
								
						if($act == 'add') 
							$sel = ["" =>""];
						else
							$sel = ["" =>""];
								//if($rowg['level']==99 AND !$_GET['level'] == '99') $s="selected"; else $s="";
								//echo "<option value='99' $s>"._Public."</option>"
						foreach($sql as $k=>$v) {
							$sel[$v['level']] = $v['group_name'];				
						}

						echo Form::select(
							's10',$sel, '',
							["class" => "form-control filter"]
						);
					?>
					</td>
				</tr>
			</table>
        </div> 
	</div>