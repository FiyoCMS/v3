<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2018 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.txt
**/

defined('_FINDEX_') or die('Access Denied');


echo Form::open( ['url' => '', 'method' => 'post']);

?>

<script>
	$(function() {
		$(".parents").chosen({disable_search_threshold: 10, 
		allow_single_deselect: true});
	});
</script>

<div class="app_header">		
	<div class="app_title">Tambah Admisi</div>
	<div class="app_link">
		<button type="submit" class="btn btn-success" title="<?php echo Save; ?>" value="<?php echo Save; ?>" name="edit_admisi"><i class="icon-check"></i> <?php echo Save; ?></button>				
		<a class="danger btn btn-default" href="?app=mutasi&view=admisi" title="<?php echo Cancel; ?>"><i class="icon-remove-sign"></i> <?php echo Cancel; ?></a>
		<?php printAlert(); ?>
	</div>			
</div>
<?php
	require('admisi.field.php');
?>

<?php Form::close(); ?>
