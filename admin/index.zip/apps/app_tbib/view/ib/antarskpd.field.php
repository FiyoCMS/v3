<?php
/**
* @version		2.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2014 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

defined('_FINDEX_') or die('Access Denied');



?>

<div class="box-left full">
	<div class="box data-step">	
		
		<?php for($i = 0 ; $i < $stepc; $i++) : $n= $i+1;	?>
		<div class="col tips <?php if($model["s$n"."_id"]) : ?> data-step-ok data-step-prev<?php endif; ?> 
			<?php  if(!$model["s$n"."_id"]) : ?> data-step-next <?php endif; ?> " 
		<?php if(!$model["s$n"."_id"]) : ?> title="Konfirmasi ke-bagian selanjutnya" <?php else: ?> 
		 title="Sudah dikonfirmasi" <?php endif; ?> 
			style="width: <?php echo $wstep;?>%"
			data-id="<?php echo $i+1; ?>" data-placement="bottom">
			
			<?php echo $i+1;?> <?php echo $group[$i]['group_name'];?>  

		<?php if(!$model["s$n"."_id"]) : ?> <span class='data-step-label'> </span>		
		<?php endif; ?> 


			<?php if($model["s$n"."_id"]) : ?><i class="icon-check"></i> <?php endif; ?>
		</div>		
		<?php endfor; ?>

	</div>
</div>

<div class="box-left full">
	<div class="box">								
		<header class="dark">
			<h5>I. Dasar Surat</h5>
		</header>								
		<div>



			<table class="form-mutasi">
				<tr>
					<td>Surat Persetujuan 1</td>
					<td>	
						<?php
							echo Form::text(
								'sp1', 
								'', 
								["class" => "form-control ", "required", "style='width: 70%'"]
							);
						?>
						</td>	
				</tr>
				<tr>
					<td>Nomor / Tanggal</td>
					<td>	
							<div>
						
							<?php
								echo Form::text(
									'no_sp1', 
									'', 
									["class" => "form-control", "required"]
								);
							?>
							/ <span> 
							<?php
								echo Form::date(
									'tgl_sp1', 
									'', 
									["class" => "form-control"]
								);
							?>
							</span>
							
						<label>
						<?php
							echo Form::checkbox(
								'tgl_sp1n', 
								'', 
								'', 
									["class" => "form-control", "", "rows" => "4"]
							);
						?>
						Tidak Bertanggal</label>
						<br>
						</div>
					</td>
				</tr>
				
				
				
				<tr>
					<td>Surat Persetujuan 2</td>
					<td>	
						<?php
							echo Form::text(
								'sp2', 
								'', 
								["class" => "form-control ", "required", "rows" => "4" ,"style='width: 70%'"]
							);
						?>
						</td>	
				</tr>
				<tr>
					<td>Nomor / Tanggal</td>
					<td>	
							<div>
							<?php
								echo Form::text(
									'no_sp2', 
									'', 
									["class" => "form-control", "required", "rows" => "4"]
								);
							?>
							/ <span> 
							<?php
								echo Form::date(
									'tgl_sp2', 
									'', 
									["class" => "form-control", "", "rows" => "4"]
								);
							?>
							</span>
							
						<label>
						<?php
							echo Form::checkbox(
								'tgl_sp2n', 
								'', 
								'', 
									["class" => "form-control", "", "rows" => "4"]
							);
						?>
						Tidak Bertanggal</label>
						<br>
						</div>
					</td>
				</tr>

					
				<tr>
					<td>Kota/Kabupaten Asal</td>
					<td>	
						<?php
							echo Form::select(
								'kab_asal',[
								3300 => "Prov Jateng",
								3301 => "Kab. Cilacap "  ,
								3302 => "Kab. Banyumas" ,
							3303=> "Kab. Purbalingga " ,
							3304=> "Kab. Banjarnegara",
							3305=>"Kab. Kebumen",
							3306=>"Kab. Purworejo",
							3307=>"Kab. Wonosobo",
							3308=>"Kab. Magelang",
							3309=>"Kab. Boyolali",
							3310=>"Kab. Klaten",
							3311=>"Kab. Sukoharjo",
							3312=>"Kab. Wonogiri",
							3313=>"Kab. Karanganyar",
							3314=>"Kab. Sragen",
							3315=>"Kab. Grobogan",
							3316=>"Kab. Blora",
							3317=>"Kab. Rembang",
							3318=>"Kab. Pati",
							3319=>"Kab. Kudus",
							3320=>"Kab. Jepara",
							3321=>"Kab. Demak",
							3322=>"Kab. Semarang",
							3323=>"Kab. Temanggung",
							3324=>"Kab. Kendal",
							3325=>"Kab. Batang",
							3326=>"Kab. Pekalongan",
							3327=>"Kab. Pemalang",
							3328=>"Kab. Tegal",
							3329=>"Kab. Brebes",
							3371=>"Kota Magelang",
							3372=>"Kota Surakarta",
							3373=>"Kota Salatiga",
							3374=>"Kota Semarang",
							3375=>"Kota Pekalongan",
							3376=>"Kota Tegal"
							], 
							'', 
								["class" => "form-control", "required"],
								'Pilih'
							);
						?>
					</td>
				</tr>
					
				<tr>
					<td>Kota/Kabupaten Tujuan</td>
					<td>
						<?php
							echo Form::select(
								'kab_tujuan',
								[3300 => "Prov Jateng",
								3301 => "Kab. Cilacap "  ,
								3302 => "Kab. Banyumas" ,
							3303=> "Kab. Purbalingga " ,
							3304=> "Kab. Banjarnegara",
							3305=>"Kab. Kebumen",
							3306=>"Kab. Purworejo",
							3307=>"Kab. Wonosobo",
							3308=>"Kab. Magelang",
							3309=>"Kab. Boyolali",
							3310=>"Kab. Klaten",
							3311=>"Kab. Sukoharjo",
							3312=>"Kab. Wonogiri",
							3313=>"Kab. Karanganyar",
							3314=>"Kab. Sragen",
							3315=>"Kab. Grobogan",
							3316=>"Kab. Blora",
							3317=>"Kab. Rembang",
							3318=>"Kab. Pati",
							3319=>"Kab. Kudus",
							3320=>"Kab. Jepara",
							3321=>"Kab. Demak",
							3322=>"Kab. Semarang",
							3323=>"Kab. Temanggung",
							3324=>"Kab. Kendal",
							3325=>"Kab. Batang",
							3326=>"Kab. Pekalongan",
							3327=>"Kab. Pemalang",
							3328=>"Kab. Tegal",
							3329=>"Kab. Brebes",
							3371=>"Kota Magelang",
							3372=>"Kota Surakarta",
							3373=>"Kota Salatiga",
							3374=>"Kota Semarang",
							3375=>"Kota Pekalongan",
							3376=>"Kota Tegal"
							], 
								'', 
								["class" => "form-control", "required"],
								'Pilih'
							);

								?>
							
					</td>
				</tr>
			<?php $row = [3300 => "Prov Jateng",
								3301 => "Kab. Cilacap "  ,
								3302 => "Kab. Banyumas" ,
							3303=> "Kab. Purbalingga " ,
							3304=> "Kab. Banjarnegara",
							3305=>"Kab. Kebumen",
							3306=>"Kab. Purworejo",
							3307=>"Kab. Wonosobo",
							3308=>"Kab. Magelang",
							3309=>"Kab. Boyolali",
							3310=>"Kab. Klaten",
							3311=>"Kab. Sukoharjo",
							3312=>"Kab. Wonogiri",
							3313=>"Kab. Karanganyar",
							3314=>"Kab. Sragen",
							3315=>"Kab. Grobogan",
							3316=>"Kab. Blora",
							3317=>"Kab. Rembang",
							3318=>"Kab. Pati",
							3319=>"Kab. Kudus",
							3320=>"Kab. Jepara",
							3321=>"Kab. Demak",
							3322=>"Kab. Semarang",
							3323=>"Kab. Temanggung",
							3324=>"Kab. Kendal",
							3325=>"Kab. Batang",
							3326=>"Kab. Pekalongan",
							3327=>"Kab. Pemalang",
							3328=>"Kab. Tegal",
							3329=>"Kab. Brebes",
							3371=>"Kota Magelang",
							3372=>"Kota Surakarta",
							3373=>"Kota Salatiga",
							3374=>"Kota Semarang",
							3375=>"Kota Pekalongan",
							3376=>"Kota Tegal"
						];

					/* foreach($row as $r => $k ) {
							echo "INSERT INTO mutasi18_kab VALUES ('', $r, '$k');";
						}*/
						?>
			</table>
		</div>
	</div>
</div>


<div class="box-left full">
	<div class="box">								
		<header class="dark">
			<h5>II. Identitas Pegawai</h5>
		</header>								
		<div>
			<table>
			<!-- IDENTITAS PEGAWAI -->
				<tr>
					<td>Nama</td>
					<td>	
						<?php
							echo Form::text(
								'nama', 
								'', 
								["class" => "form-control", "required readonly", "style" => "width: 50%"]
							);
						?>
					</td>
				</tr>
				<tr>
					<td>NIP</td>
					<td>	
						<?php
							echo Form::text(
								'nip', 
								'', 
								["class" => "form-control", "required readonly", "style" => "width: 30%"]
							);
						?>
					</td>
				</tr>
				<tr>
					<td>Tempat Lahir</td>
					<td>	
						<?php
							echo Form::text(
								'tmp_lahir', 
								'', 
								["class" => "form-control", "required disabled"]
							);
						?>
					</td>
				</tr>
				<tr>
					<td>Tanggal Lahir</td>
					<td>	
						<?php
							echo Form::date(
								'tgl_lahir', 
								'', 
								["class" => "form-control", "required  disabled"]
							);
						?>
					</td>
				</tr>
				
				<tr>
					<td>Pangkat/Gol.Ruang</td>
					<td>	
						<?php
							echo Form::select(
								'golongan', 
								[11=>"I/a - Juru Muda",12=>"I/b          ||
								Juru Muda Tingkat I      "      ,
								13=>"      I/c          ||
								Juru"                  ,
								14=>"      I/d          ||
								Juru Tingkat I  ",
								21=>" II/a          ||
								Pengatur Muda",
								22=>"   II/b          ||
								Pengatur Muda Tingkat I",
								
								23=>"  II/c          ||
								Pengatur  ",
								24=>"    II/d          ||
								Pengatur Tingkat I  ",
								31=>"III/a          ||
								Penata Muda  ",
								32=>"  III/b          ||
								Penata Muda Tingkat I ",
								33=>"   III/c          ||
								Penata        ",
								34=>"   III/d          ||
								Penata Tingkat I ",
								41=>"   IV/a          ||
								Pembina      ",
								42=>"   IV/b          ||
								Pembina Tingkat I ",
								43=>"    IV/c          ||
								Pembina Utama Muda   ",
								44=> "   IV/d          ||
								Pembina Utama Madya  ",
								45=> "  IV/e          ||
								Pembina Utama  "  ],
								'', 
								["class" => "form-control", "required  disabled", "style" => "width: 30%"]
							);
						?>
						TMT <span>
						<?php
							echo Form::date(
								'tmt', 
								'', 
								["class" => "form-control", "disabled"]
							);
						?></span>
					</td>
				</tr>
				
				<tr>
					<td>Pendidikan Terakhir</td>
					<td>	
						<?php
							echo Form::text(
								'pendidikan', 
								'', 
								["class" => "form-control", "disabled", "style" => "width: 30%"]
							);
						?>
					</td>
				</tr>

				
				<tr>
					<td>Jabatan Lama</td>
					<td>	
						<?php
							echo Form::text(
								'jabatan', 
								'', 
								["class" => "form-control", "disabled", "style" => "width: 70%"]
							);
						?>
					</td>
				</tr>
				
				<tr>
					<td>Unit Kerja Lama</td>
					<td>	
						<?php
							echo Form::text(
								'unit', 
								'', 
								["class" => "form-control", "disabled", "style" => "width: 60%"]
							);
						?>
					</td>
				</tr>
				
				<tr>
					<td>Instansi Lama</td>
					<td>	
						<?php
							echo Form::text(
								'instansi', 		
								'', 
								["class" => "form-control", "disabled", "style" => "width: 30%"]
							);
						?>
					</td>
				</tr>

			</table>
		</div>
	</div>
</div>


<div class="box-left full">
	<div class="box">								
		<header class="dark">
			<h5>III. Lampiran</h5>
		</header>								
		<div>
			<table>				
			<!-- LAMPIRAN -->
				<tr>
					<td>Lampiran Ka.SKPD</td>
					<td>	
						<?php
							echo Form::text(
								'lamp_ka_skpd', 
								'', 
								["class" => "form-control", "", "style" => "width: 50%"]
							);
						?><br><label>
						<?php
							echo Form::checkbox(
								'ubah_lamp', 
								'', 
								'', 
								["class" => "form-control", ""]
							);
						?> Ubah Lampiran </label>
					</td>
				</tr>
				<tr>
					<td>Lampiran Khusus</td>
					<td>
						<?php
							echo Form::checkbox(
								'pns_bkd', 
								'', 
								'', 
								["class" => "form-control"] ,"Pilih jika unit kerja PNS di BKD"
							);
						?>  
						<br>

					<?php
							echo Form::checkbox(
								'pns_keu', 
								'', 
								'', 
								["class" => "form-control", ""] ,"Pilih jika unit kerja PNS di Keuangan"
							)
						?>  <br>
				 <?php
							echo Form::checkbox(
								'pns_rs', 
								'', 
								'', 
								["class" => "form-control", ""] ," Pilih jika unit kerja PNS di Rumah Sakit "
							);
						?>
					</td>
				</tr>    
				<tr>
					<td>Lampiran Tambahan</td>
					<td>	
						<?php
							echo Form::text(
								'lamp_tambahan', 
								'', 
								["class" => "form-control", "", "style" => "width: 50%"]
							);
						?>
					</td>
				</tr>

				
				</table>
		</div>
	</div>
</div>



<div class="box-left full">
	<div class="box">								
		<header class="dark">
			<h5>IV. Kelengkapan Lain</h5>
		</header>								
		<div>
			<table>			
			<!-- Kelengkapan Lain -->
				<tr>
					<td>Noomor SK</td>
					<td>	
						<?php
							echo Form::text(
								'no_sk', 
								'', 
								["class" => "form-control", "", "style" => "width: 50%"]
							);
						?>
					</td>
				</tr>
				<tr>
					<td>Nomor Pengantar</td>
					<td>	
						<?php
							echo Form::text(
								'no_pengantar', 
								'', 
								["class" => "form-control", "", "style" => "width: 50%"]
							);
						?>
					</td>
				</tr>
				<tr>
					<td>Tanggal Penetapan SK</td>
					<td>	
						<?php
							echo Form::date(
								'tgl_sk', 
								'', 
								["class" => "form-control", ""]
							);
						?>
						<?php
							echo Form::hidden(
								'id', 
								'', 
								["class" => "form-control "]
							);
						?>
					</td>
				</tr>
			</table>
						
		</div>  
	</div>
</div>
 


<div class="box-left full">
	<div class="box">								
		<header class="dark">
			<h5>V. Nota Dinas</h5>
		</header>								
		<div>
			<table>			
			<!-- Kelengkapan Lain -->
				<tr>
					<td>Nota Dinas 2</td>
					<td>	
						<?php
							echo Form::text(
								'notadinas2', 
								'', 
								["class" => "form-control", "", "style" => "width: 50%"]
							);
						?>
					</td>
				</tr>

				<tr>
					<td>Nota Dinas 2</td>
					<td>	
						<?php
							echo Form::text(
								'notadinas3', 
								'', 
								["class" => "form-control", "", "style" => "width: 50%"]
							);
						?>
					</td>
				</tr>
			</table>
						
		</div>  
	</div>
</div>
 

<div class="box-left full">
	<div class="box">								
		<header class="dark">
			<h5>VI. Administrasi E-File</h5>
		</header>								
		<div>
			<table>			
				<tr>
					<td>Lampiran Administrasi
					</td>
					<td>
					
					
					<label>
						<?php
							echo Form::checkbox(
								'administrasi1', 
								'', 
								'', 
								["class" => "form-control", ""]
							);
						?> Fc. SK CPNS legalisir <br></label><br>
					<label> <?php
							echo Form::checkbox(
								'administrasi2', 
								'', 
								'', 
								["class" => "form-control", ""]
							)
						?> Fc. SK PNS legalisir<br></label><br>
					<label> <?php
							echo Form::checkbox(
								'administrasi3', 
								'', 
								'', 
								["class" => "form-control", ""]
							);
						?> Fc. SK KP terakhir legalisir <br></label><br>
						<label>
							<?php
								echo Form::checkbox(
									'administrasi4', 
									'', 
									'', 
									["class" => "form-control", ""]
								);
							?> Fc. Konversi NIP legalisir <br></label><br>
							<label> <?php
								echo Form::checkbox(
									'administrasi5', 
									'', 
									'', 
									["class" => "form-control", ""]
								)
							?> Fc. Karpeg legalisir<br></label><br>
							<label> <?php
								echo Form::checkbox(
									'administrasi6', 
									'', 
									'', 
									["class" => "form-control", ""]
								);
							?> Fc. Penyesuaian jabatan Fungsional Guru(bagi jabatan PNS Guru) <br></label>
							<label> <?php
								echo Form::checkbox(
									'administrasi7', 
									'', 
									'', 
									["class" => "form-control", ""]
								)
							?> Fc. Ijazah legalisir</label><br>
							<label> <?php
								echo Form::checkbox(
									'administrasi8', 
									'', 
									'', 
									["class" => "form-control", ""]
								);
							?> Fc. DP3/SKP 2 tahun terakhir dan <br></label><br>
							<label> <?php
									echo Form::checkbox(
										'administrasi9', 
										'', 
										'', 
										["class" => "form-control", ""]
									);
								?> Surat keterangan tidak pernah dijatuhi hukum disiplin tingkat sedang/berat dari pimpinan SKPD asal<br></label>
						
						</td>
				</tr>

				</table>
		</div>
	</div>
</div>


<!-- #helpModal -->        
<div id="konfirmasiStep" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm" role="document">

<div class="modal-content modal-infos">
      <div class="modal-header"><h4 class="modal-title">Konfirmasi Persetujuan Dokumen</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
      </div>
      <div class="modal-body">
        <p class="question">Yakin ingin melakukan konfirmasi?</p>
      </div>
      <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
            <button type="button" class="btn btn-primary data-step-setuju" >Lanjutkan</button>	
      </div>
	</div>
	
	    </div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->        
<!-- /#helpModal -->


<!-- #helpModal -->        
<div id="konfirmasiStepReject" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm" role="document">

<div class="modal-content modal-stop">
      <div class="modal-header"><h4 class="modal-title">Konfirmasi Penolakan Dokumen</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
      </div>
      <div class="modal-body">
        <p class="question">Yakin ingin merubah dan menolak data yang sudah di konfirmasi?</p>
      </div>
      <div class="modal-footer">
			<button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
            <button type="button" class="btn btn-danger data-step-tolak" >Tolak</button>	
      </div>
	</div>
	
	    </div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->        
<!-- /#helpModal -->

<script>
	 $().ready(function (){

		$(".data-step-next").click(function() {
			data = $(this).data("id");
			showPopModal();
		});

		$(".data-step-setuju").click(function() {
			setujuPosisi(<?php echo Input::get('id');?>, data);
		});

		$(".data-step-prev").click(function() {
			data = $(this).data("id");
			showPopModalReject() 
		});

		$(".data-step-tolak").click(function() {
			prevPosisi(<?php echo Input::get('id');?>, data);
		});

	 });



    function showPopModal() {
        $('#konfirmasiStep').modal('show');
	}

    function showPopModalReject() {
        $('#konfirmasiStepReject').modal('show');
	}

	function setujuPosisi(id, pos){
		$.ajax({
			type: "POST",
			url: 'apps/app_mutasi/api/step.approve.php',
			data: 'id='+id+'&pos='+pos,
			cache: false,
			async: false,
			success: function(result) {
				console.log(result);
				if(result == 0)
				console.log(result);
				else if(result == 1)
					window.location.reload();
			},
			error: function(result) {                
				
			}
		});
    }
    
	function prevPosisi(id, pos){
		$.ajax({
			type: "POST",
			url: 'apps/app_mutasi/api/step.reject.php',
			data: 'id='+id+'&pos='+pos,
			cache: false,
			async: false,
			success: function(result) {
				console.log(result);
				if(result == 0)
					console.log(result);
				else if(result == 1)
					window.location.reload();
			},
			error: function(result) {                
				
			}
		});
    }
    
</script>