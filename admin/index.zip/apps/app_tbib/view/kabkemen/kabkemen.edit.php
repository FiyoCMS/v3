<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2017 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

defined('_FINDEX_') or die('Access Denied');

$data = Restrict::antarkab();

// Koneksi ke database pegawai 	
DB::connect('eps2017','103.47.60.57','dev','12345678');
$nip = $data['nip'];	
$peg = DB::table('MASTFIP08')->select("*, tbtktdik.nm as pend ")->where("B_02B = '$nip'")
	->leftJoin("TABLOKB08","TABLOKB08.A_01=MASTFIP08.A_01 AND
	TABLOKB08.A_02=MASTFIP08.A_02 AND
	TABLOKB08.A_03=MASTFIP08.A_03 AND
	TABLOKB08.A_04=MASTFIP08.A_04 AND
	TABLOKB08.A_05=MASTFIP08.A_05")
	->leftJoin("tbtktdik","H_1A=id")
	->leftJoin("TABLOK08","kd=MASTFIP08.A_01")
	->limit(1)->get();
// Koneksi kembali
DB::reConnect();


if(isset($peg[0]['B_02B'])) {
	$data['nama'] = $peg[0]['B_03'];
	$data['nip'] = $peg[0]['B_02B'];
	$data['tgl_lahir'] = $peg[0]['B_05'];
	$data['tmp_lahir'] = $peg[0]['B_04'];
	$data['golongan'] = $peg[0]['E_05'];
	$data['tmt'] = $peg[0]['E_04'];
	$data['pendidikan'] = $peg[0]['pend'];
	$data['jabatan'] = $peg[0]['I_JB'];
	$data['unit'] = $peg[0]['nm'];
	$data['instansi'] = '';
	$dataPegawai = $peg[0];
} 

$model = array_merge($dataPegawai, $data);
	
/* Step Dokumen Berjalan */
$catId = $model['kategori'];
$cat = DB::table(FDBPrefix."mutasi_category")->where("id=$catId")->get()[0];
$group = [];
$stepc = 0;
for($i = 1; $i < 11; $i++)
	if($cat['s'.$i]) {
		$groupRow = DB::table(FDBPrefix.'user_group')->select('group_name, level')->where("id=". $cat['s'.$i])->get()[0];
		$group[$stepc] = $groupRow ;
		$stepc++;
	}

$step = $stepc;
$stepc = $stepc;
$wstep = 100/$stepc;

	
echo Form::model($model, ['url' => '', 'method' => 'post']);   

?>
	<div id="app_header">
		<div class="warp_app_header">		
		<div class="app_title">Edit Mutasi</div>		
			<div class="app_link">	
				
				<a class="btn btn-default" href="?app=mutasi&view=antarkab" title="<?php echo Cancel; ?>"><i class="icon-arrow-left"></i> <?php echo Prev; ?></a>			
				
				<?php if(USER_LEVEL < 3) : ?>
					<button type="submit" class="btn btn-success" title="<?php echo Save; ?>" value="<?php echo Save; ?>" name="edit_antarkab"><i class="icon-check"></i> <?php echo Save; ?></button>
				<?php endif; ?>	

			<?php printAlert(); ?>
			</div>
		</div>
	</div>	
	<?php 
		if(USER_LEVEL < 3)
			require('kabkemen.field.php');
		else
			require('kabkemen.field.rest.php');
	?>
</form>		