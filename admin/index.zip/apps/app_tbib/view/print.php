
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>:: SK PINDAH PNS ::</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
}
-->
</style>
<style type="text/css">
.narrow11 {
	font-family: "Times New Roman";
	font-size: 10.5pt;
	text-decoration: none;
}
.narrow12 {
	font-family: "Times New Roman";
	font-size: 12pt;
	text-decoration: none;
}
.narrow13 {
	font-family: "Times New Roman";
	font-size: 13pt;
	text-decoration: none;
}
.narrow11brd {
	font-family: "Times New Roman";
	font-size: 10.5pt;
	text-decoration: none;
	border-top-width: 1.5px;
	border-right-width: 1.5px;
	border-bottom-width: 1.5px;
	border-left-width: 1.5px;
	border-bottom-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
}
.narrow12brd {
	font-family: "Times New Roman";
	font-size: 12pt;
	text-decoration: none;
	border-top-width: 1.5px;
	border-right-width: 1.5px;
	border-bottom-width: 1.5px;
	border-left-width: 1.5px;
	border-bottom-style: solid;
	border-top-color: #000000;
	border-right-color: #000000;
	border-bottom-color: #000000;
	border-left-color: #000000;
}
.style1 {font-weight: bold}
</style>
<link href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.narrow111 {font-family: "Times New Roman";
	font-size: 10.5pt;
	text-decoration: none;
}
-->
</style>
<link href="style/stylecetak.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style2 {font-weight: bold}
-->
</style>
</head>

<body>
<table width="720" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="752"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
      <tr valign="top">
        <td height="141" colspan="8">
                    <table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="19%"><div align="center"></div></td>
              <td width="81%" height="119" valign="bottom" style="line-height: inherit"><div align="center"></div></td>
            </tr>
            <tr>
              <td colspan="2"><img src="images/spacer.gif" width="1" height="8" class="style1"></td>
            </tr>
            <tr>
              <td height="2" colspan="2"><img src="images/spacer.gif" width="1" height="2" class="style1"></td>
            </tr>
          </table>
          </td>
      </tr>
      <tr valign="top">
        <td width="5" height="" class="tahoma12">&nbsp;</td>
        <td colspan="7" class="tahoma12"><div align="center" class="tahoma12">KEPUTUSAN GUBERNUR JAWA TENGAH </div></td>
      </tr>
      <tr valign="top">
        <td height="21" class="tahoma12">&nbsp;</td>
        <td colspan="7" class="tahoma12"><div align="center" > NOMOR
              : 824.
                  3        /&nbsp;&nbsp;<strong>&nbsp;&nbsp;</strong><strong>&nbsp;&nbsp;</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong></div></td>
      </tr>
      <tr valign="top">
        <td class="tahoma12">&nbsp;</td>
        <td colspan="7" class="tahoma12"><div align="center" class="tahoma12">TENTANG</div></td>
      </tr>
      <tr valign="top">
        <td class="tahoma12">&nbsp;</td>
        <td colspan="7" class="tahoma12"><div align="center">PEMINDAHAN PEGAWAI NEGERI SIPIL<strong><br>
        </strong></div></td>
      </tr>
      <tr valign="top">
        <td colspan="8" class="tahoma12"><img src="images/spacer.gif" width="1" height="8" class="style1 style2"></td>
      </tr>
      <tr valign="top">
        <td colspan="8" class="tahoma12"><div align="center" class="tahoma12-5spac">GUBERNUR JAWA TENGAH </div></td>
      </tr>
      <tr valign="top">
        <td height="13" colspan="8"><img src="images/spacer.gif" width="1" height="8" class="style1"></td>
      </tr>
      <tr valign="top">
        <td height="63">&nbsp;</td>
        <td width="102" class="tahoma11">Menimbang </td>
        <td width="13" class="tahoma11">: </td>
        <td height="63" colspan="5" align="left" class="tahoma11"><div align="justify"> bahwa
            berdasarkan ketentuan peraturan perundang-undangan yang berlaku Pegawai
            Negeri Sipil yang tersebut dalam keputusan ini memenuhi syarat untuk
            dipindahkan antar instansi, oleh karena itu perlu ditetapkan dengan
        keputusan.</div></td>
      </tr>
      <tr valign="top">
        <td height="98">&nbsp;</td>
        <td height="98" class="tahoma11">Mengingat</td>
        <td height="98" class="tahoma11">: </td>
        <td height="98" colspan="5" align="left" class="tahoma11"><div align="justify"></div>
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr valign="top" class="tahoma11">
                <td width="3%" height="1">1.</td>
                <td width="97%" height="1"><div align="justify"> Undang-Undang Nomor 5 Tahun 2014; <br>
                </div></td>
              </tr>
              <tr valign="top" class="tahoma11">
                <td height="1">2.</td>
                <td height="1">Undang-Undang Nomor 23 Tahun 2014; </td>
              </tr>
              <tr valign="top" class="tahoma11">
                <td height="1">3.</td>
                <td height="1">Peraturan Pemerintah Nomor 9 Tahun 2003 sebagaimana telah diubah dengan  Peraturan Pemerintah
                  Nomor 63 Tahun 2009; </td>
              </tr>
              <tr valign="top" class="tahoma11">
                <td height="1">4.</td>
                <td height="1">Keputusan Kepala Badan Kepegawaian Negara Nomor 13 Tahun 2003; </td>
              </tr>
              <tr valign="top" class="tahoma11">
                <td height="27">5.</td>
                <td height="27"> Peraturan Gubernur Jawa Tengah Nomor 27 Tahun 2016.</td>
              </tr>
        </table></td>
      </tr>
      <tr valign="top">
        <td height="19">&nbsp;</td>
        <td height="19" class="tahoma11">Memperhatikan</td>
        <td height="19" class="tahoma11">: </td>
        <td height="19" colspan="5" align="left" class="tahoma11"><div align="center"></div>
            <table width="100%"  border="0" cellpadding="0" cellspacing="0">
              <tr valign="top" class="tahoma11">
                <td width="3%" height="1">1.</td>
                <td width="97%" height="1"><div align="justify"> Surat 
                  Bupati Demak                  <span class="tahoma11">
                  tanggal
24 Agustus 2017                  </span> nomor
              824.3/177; <br>
                </div></td>
              </tr>
              <tr valign="top" class="tahoma11">
                <td height="1">2.</td>
                <td height="1">Surat                  Bupati Pati            tanggal
              12 April 2018 nomor
            820/1689.</td>
              </tr>
			            </table></td>
      </tr>
      <tr valign="top">
        <td height="25" colspan="8"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td height="27"><div align="center">
                <p class="tahoma11">MEMUTUSKAN :</p>
              </div></td>
            </tr>
        </table></td>
      </tr>
      <tr valign="top">
        <td>&nbsp;</td>
        <td class="tahoma11">Menetapkan</td> <td height="19" class="tahoma11">: </td>
        <td width="40" class="tahoma11">&nbsp;</td>
        <td width="246" class="tahoma11">&nbsp;</td>
        <td width="274" class="tahoma11">&nbsp;</td>
        <td colspan="2" class="tahoma11">&nbsp;</td>
      </tr>
      <tr valign="top">
        <td height="19">&nbsp;</td>
        <td height="19" class="tahoma11">KESATU</td>
        <td height="19" class="tahoma11">: </td>
        <td height="19" colspan="5" align="justify" class="tahoma11"><span class="tahoma11">Pegawai Negeri Sipil tersebut dibawah ini : </span>
            <table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr valign="bottom" class="tahoma11" >
                <td width="29%" height="18" valign="top">N a m a</td>
                <td width="3%" valign="top">:</td>
                <td width="68%" valign="top"></strong><strong>AKAD YULIANTO, S.Pd                </strong></strong></td>
              </tr>
              <tr class="tahoma11">
                <td valign="top">Tempat / Tanggal lahir</td>
                <td valign="top">:</td>
                <td valign="top">Semarang,
                    1 Juli 1979</td>
              </tr>
              <tr class="tahoma11">
                <td valign="top">NIP</td>
                <td valign="top">:</td>
                <td valign="top">19790701 201001 1 009</td>
              </tr>
              <tr class="tahoma11">
                <td valign="top">Pendidikan Terakhir </td>
                <td valign="top">:</td>
                <td valign="top">
                  S.1 Pendidikan Pancasila dan Kewarganegaraan                </td>
              </tr>
              <tr class="tahoma11">
                <td valign="top">Pangkat/Gol.Ruang/TMT</td>
                <td valign="top">:</td>
                <td valign="top">Penata Muda Tingkat I (
            III/b            ) TMT
            1 Oktober 2013</td>
              </tr>
              <tr class="tahoma11">
                <td valign="top">Jabatan Lama </td>
                <td valign="top">:</td>
                <td valign="top">
                  <div align="left">
                    Guru Pertama SMP Negeri 2 Kayen                </div></td>
              </tr>
              <tr class="tahoma11">
                <td valign="top">Unit Kerja Lama </td>
                <td valign="top">:</td>
                <td valign="top">Dinas Pendidikan dan Kebudayaan</td>
              </tr>
              <tr valign="top" class="tahoma11">
                <td height="25" valign="top">Instansi</td>
                <td valign="top">:</td>
                <td valign="top">Pemerintah
                    Kabupaten                    Pati                </td>
              </tr>
            </table>
            <span class="tahoma11">terhitung mulai tanggal <strong>1 Mei 2018</strong> dipindahkan menjadi Pegawai Negeri Sipil pada <strong>Pemerintah
            Kabupaten            Demak</strong>.</span></td>
      </tr>
      <tr valign="top">
        <td height="10" colspan="8"><img src="images/spacer.gif" width="1" height="10" class="style1"></td>
      </tr>
      <tr valign="top">
        <td>&nbsp;</td>
        <td class="tahoma11"> KEDUA </td>
        <td class="tahoma11">:</td>
        <td colspan="5" class="tahoma11" align="justify">Apabila dikemudian hari ternyata terdapat kekeliruan dalam keputusan ini, akan diadakan perbaikan sebagaimana mestinya. </td>
      </tr>
      <tr valign="top">
        <td height="10" colspan="8"><img src="images/spacer.gif" width="1" height="10" class="style1"></td>
      </tr>
      <tr valign="top">
        <td>&nbsp;</td>
        <td class="narrow111">&nbsp;</td>
        <td class="narrow111">&nbsp;</td>
        <td align="justify" class="tahoma11"> ASLI</td>
        <td colspan="3" align="justify" class="tahoma11"> Keputusan ini diberikan kepada Pegawai Negeri Sipil yang bersangkutan untuk diketahui dan dipergunakan sebagaimana mestinya.</td>
        <td width="4" align="justify" class="tahoma11">&nbsp;</td>
      </tr>
      <tr valign="top">
        <td height="10" colspan="8"><img src="images/spacer.gif" width="1" height="10" class="style1"></td>
      </tr>
      <tr valign="top">
        <td>&nbsp;</td>
        <td class="narrow111">&nbsp;</td>
        <td class="narrow111">&nbsp;</td>
        <td colspan="5" class="tahoma11">Tembusan  Keputusan ini disampaikan kepada : </td>
      </tr>
      <tr valign="top">
        <td>&nbsp;</td>
        <td class="narrow111">&nbsp;</td>
        <td class="narrow111">&nbsp;</td>
        <td colspan="5" class="narrow111"><table width="100%" align="right" cellpadding="0" cellspacing="0">
		<tr class="tahoma11">
            <td width="12%" valign="top">&nbsp;</td>
            <td width="4%" valign="top">1.</td>
            <td colspan="2" valign="top">Gubernur Jawa Tengah;</td>
          <tr class="tahoma11">
            <td width="12%" valign="top">&nbsp;</td>
            <td width="4%" valign="top">2.</td>
            <td colspan="2" valign="top">Bupati                Demak; </td>
          <tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">3.</td>
            <td colspan="2" valign="top">Bupati                Pati;</td>
		<tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">4.</td>
            <td colspan="2" valign="top"> Sekretaris Daerah Provinsi Jawa Tengah;</td>
          </tr>
          <tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">5.</td>
            <td colspan="2" valign="top"> Kepala Kantor Regional I BKN Yogyakarta;</td>
          </tr>
                    			

          		  <tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">6.</td>
            <td colspan="2" valign="top">
			Kepala BKPP Kabupaten                Demak;
			

                </td>
          </tr>

          <tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">7.</td>
            <td colspan="2" valign="top"> Kepala BKPP			Kabupaten                Pati;</td>
          </tr>
		          <tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">8.</td>
            <td colspan="2" valign="top">Kepala                Dinas Pendidikan dan Kebudayaan                Kabupaten                Pati;
                </tr>
         	          <tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">9.</td>
            <td colspan="2" valign="top">Kepala BPKAD                Kabupaten                Pati;</td>
          </tr>
          <tr class="tahoma11">
            <td valign="top">&nbsp;</td>
            <td valign="top">10.</td>
            <td colspan="2" valign="top">Kepala BPKPAD                Kabupaten                Demak; 
				</td>
          </tr>
		   	<tr>
            <td valign="top" class="tahoma11">&nbsp;</td>
            <td valign="top" class="tahoma11">11.</td>
            <td valign="top" class="tahoma11">Kepala Bidang INKA BKD Provinsi Jawa Tengah;</td>
            <td width="5%" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td valign="top" class="tahoma11">&nbsp;</td>
            <td valign="left" class="tahoma11">12.</td>
            <td width="79%" valign="top" class="tahoma11brdtipis">Pertinggal.</td>
            <td width="5%" valign="top">&nbsp;</td>
          </tr>
        </table>
		
		</td>
      </tr>
      <tr valign="top">
        <td height="5" colspan="8"><img src="images/spacer.gif" width="1" height="2" class="style1"></td>
      </tr>
      <tr valign="top">
        <td height="166">&nbsp;</td>
        <td colspan="7" class="roman14">
          
                    <table width="100%"  border="0" cellpadding="0" cellspacing="0">
            <tr>
              <td width="54%">&nbsp;</td>
              <td width="46%" class="tahoma11">
                <div align="left">Ditetapkan di Semarang</div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td class="tahoma11"><div align="left"> pada tanggal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
            </tr>
            <tr>
              <td colspan="2"><img src="images/spacer.gif" width="1" height="8" class="style1"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td class="tahoma11"><div align="center">a.n. GUBERNUR JAWA TENGAH </div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td class="tahoma11" ><div align="center">Kepala Badan Kepegawaian Daerah</div></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td class="tahoma11">&nbsp;</td>
            </tr>
            <tr>
              <td height="39" colspan="2"><img src="images/spacer.gif" width="1" height="30" class="style1"></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td class="tahoma115"><div align="center"><span class="tahoma11">MOHAMAD ARIEF IRWANTO</span></div></td>
            </tr>
          </table>
          </td>
      </tr>
    </table>
</body>
</html>
