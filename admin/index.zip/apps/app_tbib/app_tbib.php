<?php
/**
* @version		3.0
* @package		Fiyo CMS
* @copyright	Copyright (C) 2017 Fiyo CMS.
* @license		GNU/GPL, see LICENSE.
**/

//Router File
defined('_FINDEX_') or die('Access Denied');

$app = [
	'name'		=> 'Kemajuan Pekerjaan',
	'table'		=> $_REQUEST['app'],
	'base'		=> $_REQUEST['app'],
	'folder'	=> 'app_'.$_REQUEST['app'],
];

$view = Input::get('view');
$act = Input::get('act');

switch($view)
{	
	default :
	 switch($act) {	
		default :
		 require_once('view/default.php');
		break;
		case 'add':	 
		 require('view/add_article.php');
		break;
		case 'edit':
		 require('view/edit_article.php');
		break;
		case 'view':
		 require('view/default.php');
		break;			
	}
	break;

	case 'ib': 		 
	 switch($act) {	
		default :	 
		 require('view/ib/default.php');
		break;
		case 'edit':	 
		 require('view/ib/edit.php');
		break;
		case 'add':	 
		 require('view/ib/add.php');
		break;	
		case 'print':	 
		 require('view/ib/print.php');
		break;	
	}	
	break;	
	case 'kabskpd': 		 
	 switch($act) {	
		default :	 
		 require('view/kabskpd/kabskpd.default.php');
		break;
		case 'edit':	 
		 require('view/kabskpd/kabskpd.edit.php');
		break;
		case 'add':	 
		 require('view/kabskpd/kabskpd.add.php');
		break;	
	}	
	break;	
	case 'kabkemen': 		 
	 switch($act) {	
		default :	 
		 require('view/kabkemen/kabkemen.default.php');
		break;
		case 'edit':	 
		 require('view/kabkemen/kabkemen.edit.php');
		break;
		case 'add':	 
		 require('view/kabkemen/kabkemen.add.php');
		break;	
	}	
	break;	
	case 'antarskpd': 		 
	 switch($act) {	
		default :	 
		 require('view/antarskpd/antarskpd.default.php');
		break;
		case 'edit':	 
		 require('view/antarskpd/antarskpd.edit.php');
		break;
		case 'add':	 
		 require('view/antarskpd/antarskpd.add.php');
		break;	
	}	
	break;	

	case 'skpdkab': 		 
	 switch($act) {	
		default :	 
		 require('view/skpdkab/skpdkab.default.php');
		break;
		case 'edit':	 
		 require('view/skpdkab/skpdkab.edit.php');
		break;
		case 'add':	 
		 require('view/skpdkab/skpdkab.add.php');
		break;	
	}	
	break;	
	case 'skpdkemen': 		 
	 switch($act) {	
		default :	 
		 require('view/skpdkemen/skpdkemen.default.php');
		break;
		case 'edit':	 
		 require('view/skpdkemen/skpdkemen.edit.php');
		break;
		case 'add':	 
		 require('view/skpdkemen/skpdkemen.add.php');
		break;	
	}	
	break;	
	

	case 'kemenkab': 		 
	 switch($act) {	
		default :	 
		 require('view/kemenkab/kemenkab.default.php');
		break;
		case 'edit':	 
		 require('view/kemenkab/kemenkab.edit.php');
		break;
		case 'add':	 
		 require('view/kemenkab/kemenkab.add.php');
		break;	
	}	
	break;	
	case 'kemenskpd': 		 
	 switch($act) {	
		default :	 
		 require('view/kemenskpd/kemenskpd.default.php');
		break;
		case 'edit':	 
		 require('view/kemenskpd/kemenskpd.edit.php');
		break;
		case 'add':	 
		 require('view/kemenskpd/kemenskpd.add.php');
		break;	
	}	
	break;	
	


	
	case 'admisi': 		 
	 switch($act) {
		default :	 
		 require('view/admisi/admisi.default.php');
		break;
		case 'edit':	 
		 require('view/admisi/admisi.edit.php');
		break;
		case 'add':	 
		 require('view/admisi/admisi.add.php');
		break;	
	}	

	break;	

	
	case 'print': 		 
	 switch($act) {	
		default :	 
		 require('view/print.php');
		break;
	}	
	break;	
	
}

